<?php

require dirname(__FILE__)."/utils.php";
require dirname(__FILE__)."/api_helpers.php";
require dirname(__FILE__)."/../init.php";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

$method = get_method();
$data = get_request_data();

// Log API call to Sentry
if (function_exists('\Sentry\captureMessage')) {
    \Sentry\withScope(function (\Sentry\State\Scope $scope) use ($method, $data) {
        $scope->setTag('endpoint', 'prize_pack');
        $scope->setTag('method', $method);
        $scope->setTag('service_type', $data['service_type'] ?? 'unknown');
        $scope->setContext('request', [
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        ]);
        \Sentry\captureMessage('API: prize_pack endpoint called', \Sentry\Severity::info());
    });
}

// POST request
// Store some data or something
if ($method === 'POST') {
    $data_controller;
    
    if($data["service_type"] === "School"){
        $data_controller = new SchoolVTController($data);
    }
    elseif($data["service_type"] === "Workplace"){
        $data_controller = new WorkplaceVTController($data);
    }
    elseif($data["service_type"] === "Early Years"){
        $data_controller = new EarlyYearsVTController($data);
    }
    elseif($data["service_type"] === "Imperfects"){
        $data_controller = new ImperfectsVTController($data);
    }
    else{
        $data_controller = new GeneralVTController($data);
    }
    
    $success = $data_controller->submit_prize_pack_entry();
	

	// Then, respond with a success
	send_response([
		'status' => $success ? 'success' : 'fail',
	]);
	exit;

}